Por esquecimento a tag tag_release_002.005.000.00873 teve de ser recompilada e virou tag_release_002.005.000.01135
